CREATE procedure proc_SALARY(v_EMPCODE varchar2) Is
v_workoingdays salary_details.workingdays%type;
v_salary salary_details.salary%type;
begin
select salary into v_salary from salary_details where EMPCODE = v_EMPCODE;
v_salary = v_salary * 0.95;
dbms_output.put_line(v_salary);
exception
when no_data_found then
dbms_output.put_line('未找到相应员工');
end;
/
