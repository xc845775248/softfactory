CREATE function find_emp2(eno emp.empno%type)
return emp.ename%type
 as
 name1 emp.ename%type;

 begin
   select ename into name1 from emp where empno=eno;
   return name1;
   exception
     when no_data_found then
       return '查无此人';
   end;
/
