CREATE procedure
find_emp(eno emp.empno%type)
as
--局部变量声明
name1 emp.ename%type;
begin
  select ename into name1 from emp
  where empno=eno;
  dbms_output.put_line('员工名:'||name1);
  exception
    when no_data_found then
       dbms_output.put_line('没有您要查找的员工信息');
  end;
/
