CREATE procedure find_emp1(eno emp.empno%type,name1 out varchar2)
as
begin
  select ename into name1 from emp
  where empno=eno;
  exception
    when no_data_found then
      name1:='没有改员工信息';
  end;
/
