CREATE procedure  get_salary(n_empcode salary_details.empcode%type)
as
 n_salary salary_details.salary%type;
 n_workingdays salary_details.workingdays%type;
 t_salary number;
begin
  select salary,workingdays into n_salary,n_workingdays from salary_details
  where  empcode=n_empcode;
  n_salary:=n_salary*0.95;
  t_salary:=n_salary*n_workingdays;
  dbms_output.put_line(t_salary);
  exception
    when no_data_found then
      dbms_output.put_line('没有您要查找的员工信息');
  end;
/
