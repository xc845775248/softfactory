CREATE function work_days(empco varchar2) return number
 as
 n_days number;
 n_sal  number;
 begin
   select workingdays,salary into n_days,n_sal from salary_details
   where empcode=empco;
   n_days:=22-n_days;
    if n_days>0 then
      n_sal:=n_sal-50*n_days;
    end if;
    if n_sal<0 then
      n_sal:=0;
    end if;
    return n_sal;
   end;
/
