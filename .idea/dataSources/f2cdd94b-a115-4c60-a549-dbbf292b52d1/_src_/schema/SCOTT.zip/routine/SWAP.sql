CREATE procedure swap(num1 in out number,num2 in out number)
 as
 temp number;
 begin
   temp:=num1;
   num1:=num2;
   num2:=temp;
   end;
/
