CREATE function f1 return varchar2
 as
 begin
   return 'new life';
   end;
/
