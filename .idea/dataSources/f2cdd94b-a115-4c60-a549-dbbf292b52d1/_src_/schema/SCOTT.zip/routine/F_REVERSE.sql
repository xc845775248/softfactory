CREATE function f_reverse(var in varchar2) return varchar2 as
/**
--支持数字，字符串，中文翻转
--最大支持字符串长度为32767字节
**/
  temp varchar2(32767);
  i    number(38);
begin
  if var is null
  then
    return null;
  else
    i := length(var);
    loop
      temp := temp || substr(var, i, 1);
      i    := i - 1;
      exit when i = 0;
    end loop;
    return temp;
  end if;
end;
/
