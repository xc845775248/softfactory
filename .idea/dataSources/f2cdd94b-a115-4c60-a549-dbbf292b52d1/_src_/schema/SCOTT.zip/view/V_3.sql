CREATE VIEW V_3 AS select "EMPNO","ENAME","JOB","MGR","HIREDATE","SAL","COMM","DEPTNO","DNAME","LOC" from
(select e.* ,d.dname,d.loc  from emp_temp e,dept d
where    e.deptno=d.deptno) where deptno=10 or deptno=30
with read only
/
