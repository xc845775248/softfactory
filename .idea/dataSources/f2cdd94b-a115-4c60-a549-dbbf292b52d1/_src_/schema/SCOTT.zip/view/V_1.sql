CREATE VIEW V_1 AS select "EMPNO","ENAME","JOB","MGR","HIREDATE","SAL","COMM","DEPTNO" from emp_temp
with read only
/
