CREATE VIEW V_2 AS select "EMPNO","ENAME","JOB","MGR","HIREDATE","SAL","COMM","DEPTNO" from emp_temp
with check option
/
