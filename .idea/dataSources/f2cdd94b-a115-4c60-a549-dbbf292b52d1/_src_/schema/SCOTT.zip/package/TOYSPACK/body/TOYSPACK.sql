CREATE package body toyspack
as
  procedure UpdateToyPrice
  as
  avgPrice number := AvgToyPrice;
     begin
        while (avgPrice <= 400) loop
            --循环更新
            update my_toys set price=
                 case
                    when price*1.1<500 then price*1.1
                     else price
                  end;
             avgPrice := AvgToyPrice;
             commit;
         end loop;
     end UpdateToyPrice;


     function AvgToyPrice return number
     as
        v_avg number;
     begin
        select avg(price) into v_avg from my_toys;
         return v_avg;
     end AvgToyPrice;
end toyspack;
/
