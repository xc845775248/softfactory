CREATE package toyspack
as
  procedure UpdateToyPrice;
  function AvgToyPrice return number;
end toyspack;
/
